﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Core
{
    public class Knight : Figure //конь
    {
        public Knight(string color, (int, int) position) : base(color, position)
        {
            Name = "Knight";
        }

        public override List<(int, int)> GetAvailableMoves(Figure[,] board)
        {
            var moves = new List<(int, int)>();
            int[] rowOffsets = { 2, 1, -1, -2, -2, -1, 1, 2 };
            int[] colOffsets = { 1, 2, 2, 1, -1, -2, -2, -1 };

            for (int i = 0; i < 8; i++)
            {
                int newRow = Position.row + rowOffsets[i];
                int newCol = Position.col + colOffsets[i];

                // Проверка выхода за границы доски
                if (!IsInsideBoard(newRow, newCol))
                    continue;

                // Проверка на союзную фигуру
                if (IsAlly(board, newRow, newCol))
                    continue;

                // Для проверки шаха используем временную доску
                var tempBoard = (Figure[,])board.Clone();
                tempBoard[newRow, newCol] = this;
                tempBoard[Position.row, Position.col] = null;

                // Проверяем, не останется ли король под шахом
                if (!IsKingInCheckAfterMove(tempBoard, this.Color))
                    moves.Add((newRow, newCol));
            }

            return moves;
        }

        private bool IsKingInCheckAfterMove(Figure[,] board, string color)
        {
            var kingPos = FindKing(color, board);
            foreach (var figure in board)
            {
                if (figure != null && figure.Color != color)
                {
                    if (figure.GetAvailableMoves(board).Contains(kingPos))
                        return true;
                }
            }
            return false;
        }
    }
}
